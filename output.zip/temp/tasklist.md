
# General Description

When button is pressed, it should

1. Stop Main Program, Reset WiFi Program
2. When Program Starts, ...
   1. ????, We cant even fucking connect to website, how can we do mqtt?
   2. When Program Starts, Run Offline Without MQTT
3. When Button Is Pressed, Switch To Start Server
   1. If "WiFi.json" exists, Remove File and Start Server

# Issues

1. ~~When I Publish a Message, It doesnt do jack shit~~
2. ~~If Multi-thread dies, need to restart itself~~
3. ~~When WiFi is Connecting, Allow User to Press Button and Reset~~
4. ~~Light Signal to tell which mode it is~~
